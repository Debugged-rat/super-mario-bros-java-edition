import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

abstract class Block extends NonMarioRoomElements{ //block class

    Block(int startingPositionX, int startingPositionY, int roomID, int imagePositionX, int imagePositionY, int imageWidth, int imageHeight){ //Reads image from block main image file; then each child class can specify a subimage of the main image file that is designated for that child class block
        this.objectPhysics = new Physics(startingPositionX, startingPositionY, imageWidth, imageHeight);
        this.roomID = roomID;

        try {
            this.objectMainImage = ImageIO.read(new File("Java_testing/Super_Mario_Bros_Java_Edition/Images/Blocks.png"));
        } catch (IOException e) {}

        this.objectSubImage = this.objectMainImage.getSubimage(imagePositionX, imagePositionY, imageWidth, imageHeight);
    }

    void knockUp(Mario mario){
        if(mario.getMarioForm() == 0){
            this.bounceBlock();
        } else {
            this.destroyBlock();
        }
    }

    void bounceBlock(){
    }

    void destroyBlock(){
    }

}

abstract class TileBlock extends Block {
    TileBlock(int startingPositionX, int startingPositionY, int roomID, int imagePositionX, int imagePositionY){
        super(startingPositionX, startingPositionY, roomID, imagePositionX, imagePositionY, 48, 48);
    }
}

class Ground extends TileBlock {
    Ground(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 0, 0);
        if(roomID != 1){
            this.objectSubImage = this.objectMainImage.getSubimage(0, 48, 48, 48);
        }
    }
}

class Concrete extends TileBlock {
    Concrete(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 48, 0);
        if(roomID != 1){
            this.objectSubImage = this.objectMainImage.getSubimage(48, 48, 48, 48);
        }
    }
}

class Brick extends TileBlock {
    Brick(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 96, 0);
        if(roomID != 1){
            this.objectSubImage = this.objectMainImage.getSubimage(96, 48, 48, 48);
        }
    }

    @Override
    void bounceBlock() {
        //this.bounce;
    }

    @Override
    void destroyBlock() {
        this.roomElementArrayList.remove(this);
        this.roomNonInteractableArrayList.add(new BrickDebris(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1], false, false, roomID));
        this.roomNonInteractableArrayList.add(new BrickDebris(this.objectPhysics.getPositionXY()[0] + 24, this.objectPhysics.getPositionXY()[1], true, false, roomID));
        this.roomNonInteractableArrayList.add(new BrickDebris(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1] + 24, false, true, roomID));
        this.roomNonInteractableArrayList.add(new BrickDebris(this.objectPhysics.getPositionXY()[0] + 24, this.objectPhysics.getPositionXY()[1] + 24, true, true, roomID));
    }
}

class EmptyBox extends TileBlock {
    EmptyBox(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 336, 0);
        if(roomID != 1){
            this.objectSubImage = this.objectMainImage.getSubimage(336, 48, 48, 48);
        }
    }

    @Override
    void bounceBlock() {
        
    }
}

class InvisibleConcrete extends TileBlock {
    InvisibleConcrete(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 336, 144);

    }

    @Override
    void paintElement(Graphics g, Game.GamePanel gamePanel, Camera camera) {
    }
}

class Platform extends Block {
    Platform(int startingPositionX, int startingPositionY, boolean goingUp, int roomID){
        super(startingPositionX, startingPositionY, roomID, 240, 96, 144, 24);
    }
}

abstract class MysteryBlock extends Block {
    Interactables contents;

    MysteryBlock(int startingPositionX, int startingPositionY, int roomID, int imagePositionX, int imagePositionY, Interactables contents){
        super(startingPositionX, startingPositionY, roomID, imagePositionX, imagePositionY, 48, 48);
        this.contents = contents;
    }

    @Override
    void bounceBlock() {
        this.revealContents();
    }

    @Override
    void destroyBlock() {
        this.revealContents();
    }

    void revealContents(){
        EmptyBox newEmptyBox = new EmptyBox(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1], roomID);
        this.roomElementArrayList.remove(this);
        this.roomElementArrayList.add(newEmptyBox);
        newEmptyBox.bounceBlock();
        contents.revealSelf();
    }
}

class MysteryBox extends MysteryBlock {
    MysteryBox(int startingPositionX, int startingPositionY, int roomID, Interactables contents){
        super(startingPositionX, startingPositionY, roomID, 192, 0, contents);
        this.frameDelayCountdown = new Countdown(3, true);
        this.animatedObjectFrames = new int[][] {{192, 0}, {192, 0}, {192, 0}, {240, 0}, {288, 0}, {240, 0}};
        
        if(roomID != 1){
            this.objectSubImage = this.objectMainImage.getSubimage(192, 48, 48, 48);
            this.animatedObjectFrames = new int[][] {{192, 48}, {192, 48}, {192, 48}, {240, 48}, {288, 48}, {240, 48}};
        }
    }
}

class MysteryBrick extends MysteryBlock {
    MysteryBrick(int startingPositionX, int startingPositionY, int roomID, Interactables contents){
        super(startingPositionX, startingPositionY, roomID, 96, 0, contents);
        if(roomID != 1){
            this.objectSubImage = this.objectMainImage.getSubimage(96, 48, 48, 48);
        }
    }
}

class InvisibleBox extends MysteryBlock {
    InvisibleBox(int startingPositionX, int startingPositionY, int roomID, Interactables contents){
        super(startingPositionX, startingPositionY, roomID, 336, 144, contents);
    }

    @Override
    void paintElement(Graphics g, Game.GamePanel gamePanel, Camera camera) {
    }
}

abstract class Pipe extends Block {
    Pipe(int startingPositionX, int startingPositionY, int roomID, int imageHeight){
        super(startingPositionX, startingPositionY, roomID, 0, 96, 96, imageHeight);
    }
}

class EmptyPipe extends Pipe {
    EmptyPipe(int startingPositionX, int startingPositionY, int roomID, int pipeHeight){
        super(startingPositionX, startingPositionY, roomID, pipeHeight * 48);
    }
}

class EntrancePipe extends Pipe {
    boolean locked;

    EntrancePipe(int startingPositionX, int startingPositionY, int roomID, int pipeHeight){
        super(startingPositionX, startingPositionY, roomID, pipeHeight * 48);
    }

    void enterPipe(){

    }
}

class ExitPipe extends Pipe {
    ExitPipe(int startingPositionX, int startingPositionY, int roomID, int pipeHeight){
        super(startingPositionX, startingPositionY, roomID, pipeHeight * 48);
    }

    void exitFromPipe(){

    }
}

class SideEntrancePipe extends Pipe {
    SideEntrancePipe(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 96);
        this.objectSubImage = this.objectMainImage.getSubimage(96, 96, 96, 96);
    }

    void enterPipe(){

    }
}