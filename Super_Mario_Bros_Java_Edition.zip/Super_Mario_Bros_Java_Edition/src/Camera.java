class Camera {

    private int currentCameraPosition;
    private final int[] cameraBoundaries;

    Camera(int levelID, int roomID, int cameraStartBoundary, int cameraEndBoundary){ //Camera class that specifies the small segment of the entire game that should be displayed to the player, and it locks onto Mario
        currentCameraPosition = cameraStartBoundary;
        cameraBoundaries = new int[] {cameraStartBoundary, cameraEndBoundary};
    }

    int getCurrentCameraPosition(){
        return currentCameraPosition;
    }

    void centerCameraToPlayer(Mario player){
        if(player.getPhysics().getPositionXY()[0] <= cameraBoundaries[0] + 312){
            currentCameraPosition = cameraBoundaries[0];
        } else if(player.getPhysics().getPositionXY()[0] > 312 && player.getPhysics().getPositionXY()[0] <= cameraBoundaries[1] - 456){
            currentCameraPosition = player.getPhysics().getPositionXY()[0] - 312;
        } else if(player.getPhysics().getPositionXY()[0] > cameraBoundaries[1] - 456){
            currentCameraPosition = cameraBoundaries[1];
        }
    }
}
