class Countdown {
    private final int totalFrameDelayCount;
    private final boolean cycle;
    private int currentFrameDelayCount;

    Countdown(int totalFrameDelayCount, boolean cycle){ //is a class designed to countdown in order to make it so not everything goes at the frame speed of the gameloop
        this.totalFrameDelayCount = totalFrameDelayCount;
        this.cycle = cycle;
        this.currentFrameDelayCount = 0;
    }

    void decrimentCurrentDelay(){
        if(cycle && this.currentFrameDelayCount == 0){
            resetCountdown();
        }
        if(this.currentFrameDelayCount != 0){
            this.currentFrameDelayCount--;
        }
    }

    void resetCountdown(){
        this.currentFrameDelayCount = this.totalFrameDelayCount;
    }

    int getCurrentFrameDelayCount(){
        return this.currentFrameDelayCount;
    }
}
