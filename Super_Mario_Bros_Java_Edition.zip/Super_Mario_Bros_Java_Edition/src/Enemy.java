import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

abstract class Enemy extends NonMarioRoomElements{ //Enemy abstract class, where an enemy usually downgrades/kills Mario when touched from the side, and usually dies if landed on by Mario
    
    boolean spawned;
    int constantVelocity;

    Enemy(int startingPositionX, int startingPositionY, boolean direction, boolean affectedByGravity, int roomID, int imagePositionX, int imageWidth, int imageHeight){
        this.objectPhysics = new Physics(startingPositionX, startingPositionY, imageWidth, imageHeight, direction, affectedByGravity, true);
        this.roomID = roomID;

        try {
            this.objectMainImage = ImageIO.read(new File("Java_testing/Super_Mario_Bros_Java_Edition/Images/Enemies.png"));
        } catch (IOException e) {}
        
        int imagePositionY = 0;

        if(roomID != 1){
            imagePositionY = 72;
        }

        this.objectSubImage = this.objectMainImage.getSubimage(imagePositionX, imagePositionY, imageWidth, imageHeight);
        this.animatedObjectFrames = new int[][] {{imagePositionX, imagePositionY}, {imagePositionX + 48, imagePositionY}};
        this.frameDelayCountdown = new Countdown(3, true);
    }

    abstract void playerTopCollision();
    abstract void playerSideBottomCollosion();

    void walk(){
        if(spawned){
            this.objectPhysics.setMaxVelocityX(constantVelocity);
            this.objectPhysics.setVelocity(0, constantVelocity);
        } else {
            this.objectPhysics.setMaxVelocityX(0);
            this.objectPhysics.setVelocity(0, 0);
        }
    }

    void checkIfChangeDirection(){
        if(this.objectPhysics.getDirection()){
            if(this.objectPhysics.determineSurroundingBlocks()[0][1] != null){
                this.objectPhysics.setVelocity(0, constantVelocity);
                this.objectPhysics.setDirection(!this.getPhysics().getDirection());
            }
        } else {
            if(this.objectPhysics.determineSurroundingBlocks()[0][0] != null){
                this.objectPhysics.setVelocity(0, constantVelocity);
                this.objectPhysics.setDirection(!this.getPhysics().getDirection());
            }
        }
    }
    
    void checkIfSpawned(){
        if(Math.abs(this.objectPhysics.determineDistance(this.roomPlayer)[0]) <= 936){
            this.spawned = true;
        } else {
            this.spawned = false;
        }
    }

    void die(int deathType){
        this.roomElementArrayList.remove(this);
    }
}

class Goomba extends Enemy {
    Goomba(int startingPositionX, int startingPositionY, boolean direction, int roomID){
        super(startingPositionX, startingPositionY, direction, true, roomID, 0, 48, 48);
    }

    @Override
    void die(int deathType) {
        super.die(deathType);
        if(deathType == 0){
            this.roomNonInteractableArrayList.add(new FlattenedGoomba(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1], roomID));
        } else {
            this.roomNonInteractableArrayList.add(new DeadGoomba(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1], this.roomPlayer.getPhysics().getDirection(), roomID));
        }
    }

    @Override
    void playerTopCollision() {
        this.die(0);
    }

    @Override
    void playerSideBottomCollosion() {
        this.roomPlayer.downgradeForm();
    }
}

abstract class Koopa extends Enemy {
    private final boolean colour;

    Koopa(int startingPositionX, int startingPositionY, boolean direction, int roomID, int imagePositionX, boolean colour){
        super(startingPositionX, startingPositionY, direction, true, roomID, imagePositionX, 48, 72);
        this.colour = colour;
    }
    @Override
    void die(int deathType) {
        super.die(deathType);
        if(deathType == 0){
            this.roomElementArrayList.add(new KoopaShell(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1], roomID, colour));
        } else {
            this.roomNonInteractableArrayList.add(new DeadKoopa(this.objectPhysics.getPositionXY()[0], this.objectPhysics.getPositionXY()[1], this.roomPlayer.getPhysics().getDirection(), roomID, this.colour));
        }
    }

    @Override
    void playerTopCollision() {
        this.die(0);
    }

    @Override
    void playerSideBottomCollosion() {
        this.roomPlayer.downgradeForm();
    }
}

class GreenKoopa extends Koopa {
    GreenKoopa(int startingPositionX, int startingPositionY, boolean direction, int roomID){
        super(startingPositionX, startingPositionY, direction, roomID, 96, true);
    }
}

class RedKoopa extends Koopa {
    RedKoopa(int startingPositionX, int startingPositionY, boolean direction, int roomID){
        super(startingPositionX, startingPositionY, direction, roomID, 192, false);
    }
}

class KoopaShell extends Enemy{
    KoopaShell(int startingPositionX, int startingPositionY, int roomID, boolean colour){
        super(startingPositionX, startingPositionY, true, true, roomID, 288, 48, 48);
        if(colour){
            if(roomID == 1){
                this.objectSubImage = this.objectMainImage.getSubimage(288, 0, 48, 48);
                this.animatedObjectFrames = null;
            } else {
                this.objectSubImage = this.objectMainImage.getSubimage(288, 72, 48, 48);
                this.animatedObjectFrames = null;
            }
        } else {
            if(roomID == 1){
                this.objectSubImage = this.objectMainImage.getSubimage(336, 0, 48, 48);
                this.animatedObjectFrames = null;
            } else {
                this.objectSubImage = this.objectMainImage.getSubimage(336, 72, 48, 48);
                this.animatedObjectFrames = null;
            }
        }
    }

    @Override
    void playerTopCollision() {
        this.roomPlayer.downgradeForm();
    }

    @Override
    void playerSideBottomCollosion() {
        this.roomPlayer.downgradeForm();
    }
}

class PiranhaPlant extends Enemy {
    PiranhaPlant(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, true, false, roomID, 384, 48, 72);
    }

    @Override
    void playerTopCollision() {
        this.roomPlayer.downgradeForm();
    }

    @Override
    void playerSideBottomCollosion() {
        this.roomPlayer.downgradeForm();
    }
}