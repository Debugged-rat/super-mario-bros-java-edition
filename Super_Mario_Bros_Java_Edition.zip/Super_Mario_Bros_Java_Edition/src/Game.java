import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Game {
    private JFrame gameFrame;
    private GamePanel gamePanel;
    private MyKeyListener myKeyListener;

    private Level[] allLevels;
    private int currentLevelIndex;

    private boolean leftIsHeld, rightIsHeld, upIsHeld, downIsHeld, shiftIsHeld, spaceIsHeld, enterIsHeld;
    
    Game(){ //initializes nessecary java game related classes as well as level classes
        this.gameFrame = new JFrame("Super Mario Bros Java Edition");
        this.gamePanel = new GamePanel();
        this.myKeyListener = new MyKeyListener();
        this.allLevels = new Level[] {new Level(1, 2), new Level(2, 3)};
        this.currentLevelIndex = 0;
    }
    void setUp(){
        gameFrame.setSize(768, 748);
        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameFrame.setResizable(false);
        gameFrame.add(gamePanel);
        gameFrame.setVisible(true);

        gamePanel.addKeyListener(myKeyListener);   
    }

    void runGameLoop(){
        while(true){
            gameFrame.repaint();
            try {Thread.sleep(10);} catch(Exception e){}
        }
    }

    class GamePanel extends JPanel{
        GamePanel(){
            setFocusable(true);
            requestFocusInWindow();
        }

        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            for(int i = 0; i < allLevels.length; i++){
                for(int j = 0; j < allLevels[i].getAllLevelRooms().length; j++){
                    allLevels[i].getAllLevelRooms()[j].aquirePhysicsArrayLists();
                    allLevels[i].getAllLevelRooms()[j].aquirePaintComponentParameters(g, this);
                }
            }
            
            allLevels[currentLevelIndex].getCurrentLevelRoom().paintBackground();
            allLevels[currentLevelIndex].getCurrentLevelRoom().applyPhysicsForAllRoomElements();
            allLevels[currentLevelIndex].getCurrentLevelRoom().paintAndAnimateAllRoomElements();

            if(shiftIsHeld){
                if(leftIsHeld){
                    allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().run(false);
                } else if (rightIsHeld){
                    allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().run(true);
                } else if (!leftIsHeld && !rightIsHeld){
                    allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().slow();
                }
            } else {
                if(leftIsHeld){
                    allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().walk(false);
                } else if (rightIsHeld){
                    allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().walk(true);
                } else if (!leftIsHeld && !rightIsHeld){
                    allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().slow();
                }
            }
            if(downIsHeld){
                allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().duck();
            }
            if(upIsHeld){
                allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer().jump();
            }
            allLevels[currentLevelIndex].getCurrentLevelRoom().getCamera().centerCameraToPlayer(allLevels[currentLevelIndex].getCurrentLevelRoom().getPlayer());
        }
    }

    class MyKeyListener implements KeyListener{   
        public void keyPressed(KeyEvent e){
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_A){
                leftIsHeld = true;
            } else if (key == KeyEvent.VK_D){
                rightIsHeld = true;
            } else if (key == KeyEvent.VK_W){
                upIsHeld = true;
            } else if (key == KeyEvent.VK_S){
                downIsHeld = true;
            } else if (key == KeyEvent.VK_SHIFT){
                shiftIsHeld = true;
            } else if (key == KeyEvent.VK_SPACE){
                spaceIsHeld = true;
            } else if (key == KeyEvent.VK_ENTER){
                enterIsHeld = true;
            }
        }
        public void keyReleased(KeyEvent e){ 
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_A){
                leftIsHeld = false;
            } else if (key == KeyEvent.VK_D){
                rightIsHeld = false;
            } else if (key == KeyEvent.VK_W){
                upIsHeld = false;
            } else if (key == KeyEvent.VK_S){
                downIsHeld = false;
            } else if (key == KeyEvent.VK_SHIFT){
                shiftIsHeld = false;
            } else if (key == KeyEvent.VK_SPACE){
                spaceIsHeld = false;
            }
        }   
        public void keyTyped(KeyEvent e){
        }
    }
}