import java.awt.*;


class HeadsUpDisplay { // class designed just for the HUD on the players screen that displays score, number of coins, and time
    Font headsUpDisplayFont = new Font("Press Start 2P", Font.PLAIN, 20);
    int levelID;

    Game.GamePanel gamePanel;
    Graphics g;

    HeadsUpDisplay(int levelID){
        this.levelID = levelID;
    }

    void paintHeadsUpDisplay(){
        
    }

    void aquirePaintComponentParameters(Graphics g, Game.GamePanel gamePanel){
        this.gamePanel = gamePanel;
        this.g = g;
    }
}
