import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

abstract class Interactables extends NonMarioRoomElements { //Interactables that usually do something to Mario when it comes into contact with him (e.g. upgrade his form, give him another life, give him star power, etc.)

    Boolean revealed;

    Interactables(int startingPositionX, int startingPositionY, boolean direction, boolean affectedByGravity, int roomID, int imagePositionX, int imagePositionY){
        this.objectPhysics = new Physics(startingPositionX, startingPositionY, 48, 48, direction, affectedByGravity, true);
        this.roomID = roomID;
        this.revealed = false;
        try {
            this.objectMainImage = ImageIO.read(new File("Java_testing/Super_Mario_Bros_Java_Edition/Images/Interactables.png"));
        } catch (IOException e) {}

        this.objectSubImage = this.objectMainImage.getSubimage(imagePositionX, imagePositionY, 48, 48);
    }
    
    abstract void activate();

    void revealSelf(){
        revealed = true;

    }
}

class Coin extends Interactables {
    Coin(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, true, false, roomID, 0, 0);
        this.animatedObjectFrames = new int[][] {{0, 0}, {48, 0}, {96, 0}, {0, 0}};
        this.frameDelayCountdown = new Countdown(20, true);
    }

    @Override
    void activate() {
        this.roomElementArrayList.remove(this);
    }
}

class MysteryBlockCoin extends Interactables {
    MysteryBlockCoin(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, true, true, roomID, 0, 48);
        this.animatedObjectFrames = new int[][] {{0, 48}, {48, 48}, {96, 48}, {144, 48}};
        this.frameDelayCountdown = new Countdown(10, true);
    }

    @Override
    void activate(){
        this.roomElementArrayList.remove(this);
    }
}

abstract class PowerUp extends Interactables {
    PowerUp(int startingPositionX, int startingPositionY, int roomID, int imagePositionX, int imagePositionY){
        super(startingPositionX, startingPositionY, true, true, roomID, imagePositionX, imagePositionY);
    }
}

class SuperMushroom extends PowerUp {
    SuperMushroom(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 0, 96);
    }

    @Override
    void activate() {
        this.roomPlayer.upgradeForm();
        this.roomElementArrayList.remove(this);
    }
}

class FireFlower extends PowerUp {
    FireFlower(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 0, 144);

        if(roomID == 1){
            this.animatedObjectFrames = new int[][] {{0, 144}, {48, 144}, {96, 144}, {144, 144}};
        } else {
            this.objectSubImage = this.objectMainImage.getSubimage(0, 192, 48, 48);
            this.animatedObjectFrames = new int[][] {{0, 192}, {48, 192}, {96, 192}, {144, 192}};
            this.frameDelayCountdown = new Countdown(5, true);
        }
    }

    @Override
    void activate() {
        this.roomPlayer.upgradeForm();
        this.roomElementArrayList.remove(this);
    }
}

class OneUP extends PowerUp {
    OneUP(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 48, 96);
    }

    @Override
    void activate() {
        this.roomPlayer.incrementLives();
        this.roomElementArrayList.remove(this);
    }
}

class StarPower extends PowerUp {
    StarPower(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, roomID, 0, 240);
        this.animatedObjectFrames = new int[][] {{0, 240}, {48, 240}, {96, 240}, {144, 240}};
        this.frameDelayCountdown = new Countdown(20, true);
    }

    @Override
    void activate() {
        this.roomPlayer.activateStarPower();
        this.roomElementArrayList.remove(this);
    }
}

abstract class CheckPoint extends Interactables {
    CheckPoint(int startingPositionX, int roomID, int imagePositionX, int imagePositionY){
        super(startingPositionX, 0, true, false, roomID, imagePositionX, imagePositionY);
        this.objectPhysics = new Physics(startingPositionX, 120, 48, 600, true, false, true);
    }
}

class SpawnPoint extends CheckPoint {
    private final int levelID;

    SpawnPoint(int startingPositionX, int levelID, int roomID){
        super(startingPositionX + 24, roomID, 0, 0);
        this.levelID = levelID;
    }

    @Override
    void activate() {
        Scanner spawnPointFileScanner = null;
        try {
            spawnPointFileScanner = new Scanner(new File("Java_testing/Super_Mario_Bros_Java_Edition/Text_Files/All_Level_SpawnPoints_List.txt"));    
        } catch (FileNotFoundException e) {}
        this.roomPlayer.setMarioSpawnXY(Integer.parseInt(spawnPointFileScanner.nextLine().split(" ")[this.levelID - 1]), 576);
        this.roomElementArrayList.remove(this);
        spawnPointFileScanner.close();
    }

    @Override
    void paintElement(Graphics g, Game.GamePanel gamePanel, Camera camera) {
    }
}

class Goal extends CheckPoint {
    Goal(int startingPositionX, int roomID){
        super(startingPositionX, roomID, 0, 288);
    }
    @Override
    void activate() {
        
    }

    @Override
    void paintElement(Graphics g, Game.GamePanel gamePanel, Camera camera) {
        g.drawImage(objectSubImage, this.objectPhysics.getPositionXY()[0] - camera.getCurrentCameraPosition() - 27, this.objectPhysics.getPositionXY()[1] + 24, gamePanel);
    }
}