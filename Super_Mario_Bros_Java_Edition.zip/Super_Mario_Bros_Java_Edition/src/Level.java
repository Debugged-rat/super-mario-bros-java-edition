import java.io.File;
import java.io.IOException;
import java.util.Scanner;

class Level {

    private final int levelID;
    private final Room[] levelRooms;
    private int currentRoomIndex;
    private int remainingTime;

    Level(int levelID, int totalRooms){ //initializes a number of rooms specified to each level as well as read the spawn coordinates for each room
        this.levelID = levelID;
        this.levelRooms = new Room[totalRooms];
        this.currentRoomIndex = 0;
        this.remainingTime = 400;

        int[][] levelStartingCoordinates = new int[totalRooms][2];
        boolean[] levelFreedomOfMovment = new boolean[totalRooms];

        try {
            Scanner levelStartingCoordinatesFileScanner = new Scanner(new File("Java_testing/Super_Mario_Bros_Java_Edition/Text_Files/Level_" + this.levelID + "_Room_Starting_Coordinates.txt"));
            for(int i = 0; i < totalRooms; i++){
                String roomStartingCoordinatesLine = levelStartingCoordinatesFileScanner.nextLine();
                levelStartingCoordinates[i][0] = Integer.parseInt(roomStartingCoordinatesLine.split(" ")[0]);
                levelStartingCoordinates[i][1] = Integer.parseInt(roomStartingCoordinatesLine.split(" ")[1]);
                levelFreedomOfMovment[i] = Boolean.parseBoolean(roomStartingCoordinatesLine.split(" ")[2]);
            }
        } catch (IOException e) {}
        

        for(int i = 0; i < totalRooms; i++){
            this.levelRooms[i] = new Room(levelID, i + 1, levelStartingCoordinates[i][0], levelStartingCoordinates[i][1], levelFreedomOfMovment[i]);
        }
    }

    Room[] getAllLevelRooms(){ //getters and setters
        return this.levelRooms;
    }

    Room getCurrentLevelRoom() {
        return this.levelRooms[this.currentRoomIndex];
    }

    void setCurrentRoomIndex(int roomIndex){
        this.currentRoomIndex = roomIndex;
    }
}
