/*
@Author: Henry Yang
@Version: Janurary 30

This is a clone of the game Super Mario Bros NES from 1998, where the player uses the WASD, shift, and space bar buttons to move mario to complete an 'obstacle course' by making it to the end of the game
This game is designed in a way that can be easily scaled up, where all a person needs to do to add more levels and rooms in those levels is to add more text files to the folder, without the need of writing any extra code.

*/

public class MainProgram {
    public static void main(String[] args){
        Game game = new Game();
        game.setUp();
        game.runGameLoop();
    }
}