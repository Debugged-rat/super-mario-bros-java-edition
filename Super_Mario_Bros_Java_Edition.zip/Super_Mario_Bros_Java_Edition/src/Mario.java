import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

class Mario extends RoomElements {
    private static int playerScore = 0;
    private static int marioLives = 3;
    private static int marioForm = 0;

    private Countdown invulnerableCountdown;
    private Countdown starPowerCountdown;
    
    private final int[] playerSpawnXY = new int[2];

    private Countdown walkCountdown = new Countdown(8, true);
    private Countdown walkFrameCountdown = new Countdown(3, true);
    private int imagePositionX = 0;
    private int imagePositionY = 0;
    private boolean jumped;
    private boolean ducked;

    Mario(int playerSpawnX, int playerSpawnY, int roomID){ //Initializes usual RoomElement fields as well as Mario specific fields such as invulnerableCountdown and starPowerCountdown
        this.objectPhysics = new Physics(playerSpawnX, playerSpawnY, 48, 48, true, true, true);
        this.playerSpawnXY[0] = playerSpawnX;
        this.playerSpawnXY[1] = playerSpawnY;
        this.roomID = roomID;
        this.invulnerableCountdown = new Countdown(500, false);
        this.starPowerCountdown = new Countdown(1000, false);
        try {
            this.objectMainImage = ImageIO.read(new File("Java_testing/Super_Mario_Bros_Java_Edition/Images/Mario.png"));
        } catch (IOException e) {}

        this.jumped = false;
        this.ducked = false;
    }

    int getMarioForm(){ //getters and setters
        return marioForm;
    }

    int[] getMarioSpawnXY(){
        return playerSpawnXY;
    }

    void setMarioSpawnXY(int newPlayerSpawnX, int newPlayerSpawnY){
        this.playerSpawnXY[0] = newPlayerSpawnX;
        this.playerSpawnXY[1] = newPlayerSpawnY;
    }

    void upgradeForm(){ //upgrades mario form from normal to super to fire power
        if(marioForm == 0){
            this.objectPhysics.setHitBoxY(96);
            marioForm++;
        } else if (marioForm == 1){
            marioForm++;
        }
    }

    void downgradeForm(){ //always downgrades to normal form unless they already were, in that case they die
        if(marioForm == 1 || marioForm == 2){
            this.activateInvulnerability();
            this.objectPhysics.setHitBoxY(48);
            marioForm = 0;
        } else {
            this.die(0);
        }
    }

    void incrementLives(){
        marioLives++;
    }

    void decrementLives(){
        marioLives--;
    }

    void walk(boolean direction){ //walks depending on direction, changing acceleration instead of velocity to make walking look smoother
        Block[] blocksOnSidesOfPlayer = this.objectPhysics.determineSurroundingBlocks()[0];
        if(this.objectPhysics.getAirborne()){
            if(direction){
                this.objectPhysics.setAcceleration(0, 1);
            } else {
                this.objectPhysics.setAcceleration(0, -1);
            }
        } else {
            this.objectPhysics.setMaxVelocityX(6);
            if(direction){
                this.objectPhysics.setAcceleration(0, 2);
            } else {
                this.objectPhysics.setAcceleration(0, -2);
            }
        }
        if(this.objectPhysics.getVelocityXY()[0] > 0 && blocksOnSidesOfPlayer[1] != null){
            this.objectPhysics.setVelocity(0, 0);
        } else if(this.objectPhysics.getVelocityXY()[0] < 0 && blocksOnSidesOfPlayer[0] != null){
            this.objectPhysics.setVelocity(0, 0);
        }
    }

    void run(boolean direction){ //same as walking method, except accelerates faster and has higher maximum speed
        Block[] blocksOnSidesOfPlayer = this.objectPhysics.determineSurroundingBlocks()[0];
        if(this.objectPhysics.getAirborne()){
            if(direction){
                this.objectPhysics.setAcceleration(0, 2);
            } else {
                this.objectPhysics.setAcceleration(0, -2);
            }
        } else {
            this.objectPhysics.setMaxVelocityX(10);
            if(direction){
                this.objectPhysics.setAcceleration(0, 3);
            } else {
                this.objectPhysics.setAcceleration(0, -3);
            }
        }
        if(this.objectPhysics.getVelocityXY()[0] > 0 && blocksOnSidesOfPlayer[1] != null){
            this.objectPhysics.setVelocity(0, 0);
        } else if(this.objectPhysics.getVelocityXY()[0] < 0 && blocksOnSidesOfPlayer[0] != null){
            this.objectPhysics.setVelocity(0, 0);
        }
    }

    void jump(){ //makes sure the player can only jump while standing on the ground
        if(!this.jumped && !this.ducked){
            this.objectPhysics.setVelocity(1, -250);
            this.jumped = true;
        }
    }

    void duck(){ 
        Block blockUnderMario = this.objectPhysics.determineSurroundingBlocks()[1][1];

        if(marioForm >= 1 && !this.objectPhysics.getAirborne() && !this.jumped){
            if(this.objectPhysics.getVelocityXY()[0] != 0){
                this.objectPhysics.setAcceleration(0, -Integer.signum(this.objectPhysics.getAccelerationXY()[0]));
                this.ducked = true;
            }
        }
        if(blockUnderMario != null){
            if(blockUnderMario.getClass().getSimpleName().equals("EntrancePipe")){

            }
        }
    }

    void slow(){ //makes it so when the player stops pressing keys to move they decelerate for a smoother stopping process
        Block[] blocksOnSidesOfPlayer = this.objectPhysics.determineSurroundingBlocks()[0];

        if(Integer.signum(this.objectPhysics.getVelocityXY()[0]) > 0){
            this.objectPhysics.setAcceleration(0, -2);
        } else if(Integer.signum(this.objectPhysics.getVelocityXY()[0]) < 0){
            this.objectPhysics.setAcceleration(0, 2);
        } else {
            this.objectPhysics.setAcceleration(0, 0);
        }
        if(this.objectPhysics.getVelocityXY()[0] > 0 && blocksOnSidesOfPlayer[1] != null){
            this.objectPhysics.setVelocity(0, 0);
        } else if(this.objectPhysics.getVelocityXY()[0] < 0 && blocksOnSidesOfPlayer[0] != null){
            this.objectPhysics.setVelocity(0, 0);
        }
    }

    void checkIfJumped(){
        if(this.jumped && !this.objectPhysics.getAirborne()){
            this.jumped = false;
        }
    }

    void checkIfDucked(){
        if(this.ducked && this.objectPhysics.getAirborne()){
            this.ducked = false;
        } else if (!this.ducked && this.objectPhysics.determineSurroundingBlocks()[1][0] != null){
            this.ducked = true;
            if(this.getPhysics().getVelocityXY()[0] < 2 && this.getPhysics().getVelocityXY()[0] >= 0){
                this.getPhysics().setVelocity(0, 2);
            } else if (this.getPhysics().getVelocityXY()[0] > -2 && this.getPhysics().getVelocityXY()[0] <= 0){
                this.getPhysics().setVelocity(0, -2);
            }
        }
    }

    void activateMysteryBlock(){
        Block blockOnTopOfMario = this.objectPhysics.determineSurroundingBlocks()[1][0];
        MysteryBlock mysteryBlockOnTopOfMario;
        String blockOnTopOfMarioClassName = null;
        if(blockOnTopOfMario != null){
            blockOnTopOfMarioClassName = this.objectPhysics.determineSurroundingBlocks()[1][0].getClass().getSimpleName();
        }
        if(blockOnTopOfMario != null){
            if(blockOnTopOfMarioClassName.equals("MysteryBox") || blockOnTopOfMarioClassName.equals("MysteryBrick") || blockOnTopOfMarioClassName.equals("InvisibleBox")){
                mysteryBlockOnTopOfMario = (MysteryBlock)blockOnTopOfMario;
                if(this.objectPhysics.getVelocityXY()[1] < 0){
                    mysteryBlockOnTopOfMario.revealContents();
                }
            }
        }
    }

    void activateEnemyAction(){
        Enemy[][] surroundingEnemies = this.objectPhysics.determineSurroundingEnemies();

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 2; j++){
                if(surroundingEnemies[i][j] != null){
                    if(i == 1 && this.objectPhysics.getVelocityXY()[1] > 0){
                        surroundingEnemies[i][j].playerTopCollision();
                    } else {
                        surroundingEnemies[i][j].playerSideBottomCollosion();
                    }
                }
            }
        }
    }

    void activateInteractables(){
        Interactables touchingInteractable = this.objectPhysics.determineTouchingInteractable();
        if(touchingInteractable != null){
            touchingInteractable.activate();
        }
    }

    void activateInvulnerability(){
        this.invulnerableCountdown.resetCountdown();
    }

    void activateStarPower(){
        this.starPowerCountdown.resetCountdown();
    }

    void decrimentCountdowns(){
        this.invulnerableCountdown.decrimentCurrentDelay();
        this.starPowerCountdown.decrimentCurrentDelay();
        if(this.objectPhysics.getVelocityXY()[0] != 0 && !this.objectPhysics.getAirborne()){
            this.walkCountdown.decrimentCurrentDelay();
        } else {
            this.walkCountdown.resetCountdown();
            this.walkFrameCountdown.resetCountdown();
        }
    }

    void animateMario(){
        if(this.objectPhysics.getVelocityXY()[0] != 0 && !this.objectPhysics.getAirborne()){
            if(Integer.signum(this.objectPhysics.getAccelerationXY()[0]) * Integer.signum(this.objectPhysics.getVelocityXY()[0]) == 1){
                imagePositionX = 144 - (this.walkFrameCountdown.getCurrentFrameDelayCount() * 48);
                if(this.walkCountdown.getCurrentFrameDelayCount() % (14 - this.objectPhysics.getVelocityXY()[0]) == 0){
                    this.walkFrameCountdown.decrimentCurrentDelay();
                } 
            } else {
                imagePositionX = 192;
            }
        }
        if (this.jumped) {
            imagePositionX = 240;
        } else if (this.ducked){
            imagePositionX = 432;
        }
        if(invulnerableCountdown.getCurrentFrameDelayCount() != 0){
            if(invulnerableCountdown.getCurrentFrameDelayCount()/5 % 2 == 0){
                imagePositionX = 432;
            }
        }
        if(starPowerCountdown.getCurrentFrameDelayCount() == 0){
            if(marioForm == 0){
                imagePositionY = 96;
            } else if(marioForm == 2){
                imagePositionY = 144;
            }
        } else {
            if(starPowerCountdown.getCurrentFrameDelayCount() > 350){
                if(marioForm == 0){
                    imagePositionY = 96 + (starPowerCountdown.getCurrentFrameDelayCount()/5 % 3) * 144;
                } else {
                    imagePositionY = 384 + (starPowerCountdown.getCurrentFrameDelayCount()/5 % 3) * 144;
                }
            } else {
                if(marioForm == 0){
                    imagePositionY = 96 + (starPowerCountdown.getCurrentFrameDelayCount()/20 % 3) * 144;
                } else {
                    imagePositionY = 384 + (starPowerCountdown.getCurrentFrameDelayCount()/20 % 3) * 144;
                }
            }
            
        }
        this.objectSubImage = this.objectMainImage.getSubimage(imagePositionX, imagePositionY, this.objectPhysics.getHitBoxXY()[0], this.objectPhysics.getHitBoxXY()[1]);
    }

    void die(int deathType){
    }
}