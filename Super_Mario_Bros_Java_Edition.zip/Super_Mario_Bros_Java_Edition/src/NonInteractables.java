import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

abstract class NonInteractables extends NonMarioRoomElements{ //Used for things that Mario cannot collide with, but is painted onto the screen such as dead goomba afterimages and brick debris

    Countdown despawnCountdown;

    NonInteractables(int startingPositionX, int startingPositionY, boolean direction, boolean affectedByGravity, int roomID, int imagePositionX, int imagePositionY, int imageWidth, int imageHeight, int despawnDuration){
        this.objectPhysics = new Physics(startingPositionX, startingPositionY, imageWidth, imageHeight, direction, affectedByGravity, false);
        this.roomID = roomID;

        try {
            this.objectMainImage = ImageIO.read(new File("Java_testing/Super_Mario_Bros_Java_Edition/Images/NonInteractables.png"));
        } catch (IOException e) {}

        this.objectSubImage = this.objectMainImage.getSubimage(imagePositionX, imagePositionY, imageWidth, imageHeight);
        this.despawnCountdown = new Countdown(despawnDuration, false);
    }
}

class FlattenedGoomba extends NonInteractables {
    FlattenedGoomba(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, true, false, roomID, 0, 0, 48, 48, 15);
    }
}

class DeadGoomba extends NonInteractables {
    DeadGoomba(int startingPositionX, int startingPositionY, boolean direction, int roomID){
        super(startingPositionX, startingPositionY, direction, true, roomID, 48, 0, 48, 48, 50);
        if(direction){
            this.objectPhysics.setVelocity(0, 4);
        } else {
            this.objectPhysics.setVelocity(0, -4);
        }
        this.objectPhysics.setVelocity(1, -50);
    }
}

class DeadKoopa extends NonInteractables {
    DeadKoopa(int startingPositionX, int startingPositionY, boolean direction, int roomID, boolean colour){
        super(startingPositionX, startingPositionY, direction, true, roomID, 96, 0, 48, 48, 50);
    }
}

class BrickDebris extends NonInteractables {
    BrickDebris(int startingPositionX, int startingPositionY, boolean directionX, boolean directionY, int roomID){
        super(startingPositionX, startingPositionY, directionX, true, roomID, 192, 0, 24, 24, 50);
        if(roomID == 1){
            if(directionX){
                if(directionY){
                    this.objectSubImage = this.objectMainImage.getSubimage(216, 24, 24, 24);
                    this.animatedObjectFrames = new int[][] {{216, 0}, {216, 24}};
                } else {
                    this.objectSubImage = this.objectMainImage.getSubimage(216, 0, 24, 24);
                    this.animatedObjectFrames = new int[][] {{216, 24}, {216, 0}};
                }
            } else {
                if(directionY){
                    this.objectSubImage = this.objectMainImage.getSubimage(192, 24, 24, 24);
                    this.animatedObjectFrames = new int[][] {{192, 0}, {192, 24}};
                } else {
                    this.objectSubImage = this.objectMainImage.getSubimage(192, 0, 24, 24);
                    this.animatedObjectFrames = new int[][] {{192, 24}, {192, 0}};
                }
            }
        } else {
            if(directionX){
                if(directionY){
                    this.objectSubImage = this.objectMainImage.getSubimage(216, 72, 24, 24);
                    this.animatedObjectFrames = new int[][] {{216, 48}, {216, 72}};
                } else {
                    this.objectSubImage = this.objectMainImage.getSubimage(216, 48, 24, 24);
                    this.animatedObjectFrames = new int[][] {{216, 72}, {216, 48}};
                }
            } else {
                if(directionY){
                    this.objectSubImage = this.objectMainImage.getSubimage(192, 72, 24, 24);
                    this.animatedObjectFrames = new int[][] {{192, 48}, {192, 72}};
                } else {
                    this.objectSubImage = this.objectMainImage.getSubimage(192, 48, 24, 24);
                    this.animatedObjectFrames = new int[][] {{192, 72}, {192, 48}};
                }
            }
        }
        this.frameDelayCountdown = new Countdown(5, true);
    }
}

class FireballExplosion extends NonInteractables {
    FireballExplosion(int startingPositionX, int startingPositionY, int roomID){
        super(startingPositionX, startingPositionY, true, false, roomID, 240, 0, 48, 48, 6);
        this.animatedObjectFrames = new int[][] {{288, 0}, {336, 0}};
        this.frameDelayCountdown = new Countdown(2, false);
    }
}