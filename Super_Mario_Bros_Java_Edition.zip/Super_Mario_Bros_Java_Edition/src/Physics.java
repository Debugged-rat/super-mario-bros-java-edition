import java.util.ArrayList;

class Physics { //Each roomElement has a physics class that specifies its position, velocity, acceleration, etc.

    private final int[] positionXY = new int[2];
    private final int[] velocityXY = new int[2];
    private final int[] maxVelocityXY = new int[2];
    private final int[] accelerationXY = new int[2];
    private final int[] hitBoxXY = new int[2];

    private boolean direction;
    private boolean airborne;
    private final boolean affectedByGravity;
    private final boolean tangible;

    private Mario roomPlayer;
    private ArrayList<Block> roomBlockList;
    private ArrayList<Interactables> roomInteractablesList;
    private ArrayList<Enemy> roomEnemyList;
    
    Physics(int startingPositionX, int startingPositionY, int hitBoxX, int hitBoxY, boolean direction, boolean affectedByGravity, boolean tangible){

        this.positionXY[0] = startingPositionX;
        this.positionXY[1] = startingPositionY;

        this.hitBoxXY[0] = hitBoxX;
        this.hitBoxXY[1] = hitBoxY;

        this.velocityXY[0] = 0;
        this.velocityXY[1] = 0;

        this.maxVelocityXY[0] = 8;
        this.maxVelocityXY[1] = 50;

        this.direction = direction;
        this.airborne = false;
        this.affectedByGravity = affectedByGravity;
        this.tangible = tangible;
    }
    
    Physics(int startingPositionX, int startingPositionY, int hitBoxX, int hitBoxY){

        this.positionXY[0] = startingPositionX;
        this.positionXY[1] = startingPositionY;

        this.hitBoxXY[0] = hitBoxX;
        this.hitBoxXY[1] = hitBoxY;

        this.velocityXY[0] = 0;
        this.velocityXY[1] = 0;

        this.maxVelocityXY[0] = 0;
        this.maxVelocityXY[1] = 0;

        this.direction = true;
        this.airborne = true;
        this.affectedByGravity = false;
        this.tangible = true;
    }

    int[] getPositionXY(){
        return this.positionXY;
    }

    int[] getVelocityXY(){
        return this.velocityXY;
    }

    int[] getAccelerationXY(){
        return this.accelerationXY;
    }

    int[] getHitBoxXY(){
        return this.hitBoxXY;
    }

    boolean getDirection(){
        return this.direction;
    }

    boolean getAirborne(){
        return this.airborne;
    }

    void setPositionXY(int dimension, int position) {
        this.positionXY[dimension] = position;
    }

    void setVelocity(int dimension, int velocity){
        this.velocityXY[dimension] = velocity;
    }

    void setMaxVelocityX(int maxVelocity){
        this.maxVelocityXY[0] = Math.abs(maxVelocity);
    }

    void setAcceleration(int dimension, int acceleration){
        this.accelerationXY[dimension] = acceleration;

        if(acceleration > 0){
            this.direction = true;
        } else if(acceleration < 0){
            this.direction = false;
        }
    }

    void setHitBoxY(int hitBoxY){
        this.hitBoxXY[1] = hitBoxY;
    }

    void setDirection(boolean direction){
        this.direction = direction;
    }

    void checkIfAirborne(){
        if(this.tangible){
            if(affectedByGravity && this.determineSurroundingBlocks()[1][1] == null){
                airborne = true;
            } else {
                airborne = false;
            }
        }
    }

    void applyVelocity(){
        for(int i = 0; i < 2; i++){
            if(this.determineSurroundingBlocks()[i][Math.max(0, Integer.signum(this.velocityXY[i]))] == null && this.tangible){
                this.positionXY[i] += this.velocityXY[i];
            }
        }
    }

    void applyAcceleration(){
        this.velocityXY[0] += this.accelerationXY[0];
        this.velocityXY[1] += this.accelerationXY[1];

        for(int i = 0; i < 2; i++){
            if(Math.abs(this.velocityXY[i]) > Math.abs(this.maxVelocityXY[i])){
                this.velocityXY[i] = this.maxVelocityXY[i] * Integer.signum(this.velocityXY[i]);
            }
        }
    }

    void applyGravity(){
        if(affectedByGravity && airborne){
            this.accelerationXY[1] = 8;
        } else {
            this.velocityXY[1] = 0;
            this.accelerationXY[1] = 0;
        }
    }

    int[] determineDistance(RoomElements other){
        int[] distanceXY = new int[2];
        distanceXY[0] = (this.positionXY[0] + (this.hitBoxXY[0] / 2)) - (other.getPhysics().getPositionXY()[0] + (other.getPhysics().getHitBoxXY()[0] / 2));
        distanceXY[1] = (this.positionXY[1] + (this.hitBoxXY[1] / 2)) - (other.getPhysics().getPositionXY()[1] + (other.getPhysics().getHitBoxXY()[1] / 2));
        return distanceXY;
    }

    Block[][] determineSurroundingBlocks(){
        Block[][] surroundingBlocks = {{null, null}, {null, null}};
        for(int i = 0; i < 2; i++){
            for(int j = 0; j < roomBlockList.size(); j++){
                if(this.determineDistance(roomBlockList.get(j))[i] >= 0 && this.determineDistance(roomBlockList.get(j))[i] <= (this.hitBoxXY[i] + roomBlockList.get(j).getPhysics().getHitBoxXY()[i]) / 2 && Math.abs(this.determineDistance(roomBlockList.get(j))[Math.abs(i - 1)]) <= Math.max(this.hitBoxXY[Math.abs(i - 1)], roomBlockList.get(j).getPhysics().getHitBoxXY()[Math.abs(i - 1)]) / 2){
                    surroundingBlocks[i][0] = roomBlockList.get(j);
                } else if (this.determineDistance(roomBlockList.get(j))[i] <= 0 && this.determineDistance(roomBlockList.get(j))[i] >= (this.hitBoxXY[i] + roomBlockList.get(j).getPhysics().getHitBoxXY()[i]) / 2 && Math.abs(this.determineDistance(roomBlockList.get(j))[Math.abs(i - 1)]) <= Math.max(this.hitBoxXY[Math.abs(i - 1)], roomBlockList.get(j).getPhysics().getHitBoxXY()[Math.abs(i - 1)]) / 2){
                    surroundingBlocks[i][1] = roomBlockList.get(j);
                }
            }
        }
        return surroundingBlocks;
    }

    Interactables determineTouchingInteractable(){
        Interactables touchingInteractable = null;
        for(int i = 0; i < 2; i++){
            for(int j = 0; j < roomInteractablesList.size(); j++){
                if(this.determineDistance(roomEnemyList.get(j))[i] >= 0 && this.determineDistance(roomInteractablesList.get(j))[i] <= (this.hitBoxXY[i] + roomInteractablesList.get(j).getPhysics().getHitBoxXY()[i]) / 2 && Math.abs(this.determineDistance(roomInteractablesList.get(j))[Math.abs(i - 1)]) <= Math.max(this.hitBoxXY[Math.abs(i - 1)], roomInteractablesList.get(j).getPhysics().getHitBoxXY()[Math.abs(i - 1)]) / 2){
                    touchingInteractable = roomInteractablesList.get(j);
                } else if (this.determineDistance(roomBlockList.get(j))[i] <= 0 && this.determineDistance(roomInteractablesList.get(j))[i] >= (this.hitBoxXY[i] + roomInteractablesList.get(j).getPhysics().getHitBoxXY()[i]) / 2 && Math.abs(this.determineDistance(roomInteractablesList.get(j))[Math.abs(i - 1)]) <= Math.max(this.hitBoxXY[Math.abs(i - 1)], roomInteractablesList.get(j).getPhysics().getHitBoxXY()[Math.abs(i - 1)]) / 2){
                    touchingInteractable = roomInteractablesList.get(j);
                }
            }
        }
        return touchingInteractable;
    }

    Enemy[][] determineSurroundingEnemies(){
        Enemy[][] surroundingEnemies = {{null, null}, {null, null}};
        for(int i = 0; i < 2; i++){
            for(int j = 0; j < roomEnemyList.size(); j++){
                if(this.determineDistance(roomEnemyList.get(j))[i] >= 0 && this.determineDistance(roomEnemyList.get(j))[i] <= (this.hitBoxXY[i] + roomEnemyList.get(j).getPhysics().getHitBoxXY()[i]) / 2 && Math.abs(this.determineDistance(roomEnemyList.get(j))[Math.abs(i - 1)]) <= Math.max(this.hitBoxXY[Math.abs(i - 1)], roomEnemyList.get(j).getPhysics().getHitBoxXY()[Math.abs(i - 1)]) / 2){
                    surroundingEnemies[i][0] = roomEnemyList.get(j);
                } else if (this.determineDistance(roomBlockList.get(j))[i] <= 0 && this.determineDistance(roomEnemyList.get(j))[i] >= (this.hitBoxXY[i] + roomEnemyList.get(j).getPhysics().getHitBoxXY()[i]) / 2 && Math.abs(this.determineDistance(roomEnemyList.get(j))[Math.abs(i - 1)]) <= Math.max(this.hitBoxXY[Math.abs(i - 1)], roomEnemyList.get(j).getPhysics().getHitBoxXY()[Math.abs(i - 1)]) / 2){
                    surroundingEnemies[i][1] = roomEnemyList.get(j);
                }
            }
        }
        return surroundingEnemies;
    }

    boolean nullRoomElements(){
        return this.roomPlayer == null;
    }

    void aquireRoomAllElements(Mario roomPlayer, ArrayList<Block> roomBlockList, ArrayList<Interactables> roomInteractablesList, ArrayList<Enemy> roomEnemyList){
        if(this.roomPlayer == null){
            this.roomPlayer = roomPlayer;
            this.roomBlockList = roomBlockList;
            this.roomInteractablesList = roomInteractablesList;
            this.roomEnemyList = roomEnemyList;
        }
    }
}
