import java.awt.*;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

class Room {

    private final int levelID;
    private final int roomID;

    private final Mario player;
    private Camera camera;

    private BufferedImage roomBackground;
    private BufferedImage centeredRoomBackground;

    private final ArrayList<Block> roomBlockList;
    private final ArrayList<Interactables> roomInteractablesList;
    private final ArrayList<NonInteractables> roomNonInteractablesList;
    private final ArrayList<Enemy> roomEnemyList;

    private Game.GamePanel gamePanel;
    private Graphics g;

    @SuppressWarnings("unchecked")
    Room(int levelID, int roomID, int playerSpawnX, int playerSpawnY, boolean initialFreedomOfMovement){ //each room contains a Camera and Mario object, as well as ArrayLists of Blocks, Interactables, NonInteractables, and Enemies. The constructor reads from level/room specific text files that contain data for each object
        this.levelID = levelID;
        this.roomID = roomID;

        this.player = new Mario(playerSpawnX, playerSpawnY, roomID);

        try {                
            this.roomBackground = ImageIO.read(new File("Java_testing/Super_Mario_Bros_Java_Edition/Images/Level_" + this.levelID + "_Room_" + this.roomID + "_Background.png"));
        } catch (IOException e){}

        this.roomBlockList = new ArrayList<Block>();
        this.roomInteractablesList = new ArrayList<Interactables>();
        this.roomNonInteractablesList = new ArrayList<NonInteractables>();
        this.roomEnemyList = new ArrayList<Enemy>();

        Scanner cameraBoundariesFileScanner = null;
        Scanner blockMapFileScanner = null;
        Scanner interactablesMapFileScanner = null;
        Scanner enemyListFileScanner = null;

        try {
            cameraBoundariesFileScanner = new Scanner(new File("Java_testing/Super_Mario_Bros_Java_Edition/Text_Files/Level_" + this.levelID + "_Room_Camera_Boundaries.txt"));
            blockMapFileScanner = new Scanner(new File("Java_testing/Super_Mario_Bros_Java_Edition/Text_Files/Level_" + this.levelID + "_Room_" + this.roomID + "_Block_Map.txt"));
            interactablesMapFileScanner = new Scanner(new File("Java_testing/Super_Mario_Bros_Java_Edition/Text_Files/Level_" + this.levelID + "_Room_" + this.roomID + "_Interactables_Map.txt"));
            enemyListFileScanner = new Scanner(new File("Java_testing/Super_Mario_Bros_Java_Edition/Text_Files/Level_" + this.levelID + "_Room_" + this.roomID + "_Enemy_List.txt"));
        } catch (FileNotFoundException e) {}
    
        String currentCameraLine = "";
        for(int i = 0; i < this.roomID; i++){
            currentCameraLine = cameraBoundariesFileScanner.nextLine();
        }
        this.camera = new Camera(levelID, roomID, Integer.parseInt(currentCameraLine.split(" ")[0]), Integer.parseInt(currentCameraLine.split(" ")[1]));
        cameraBoundariesFileScanner.close();

        int currentLineIndex = 0;
        while (blockMapFileScanner.hasNextLine()){
            String currentBlockLine = blockMapFileScanner.nextLine();
            String currentInteractableLine = interactablesMapFileScanner.nextLine();

            Block currentBlock = null;
            Interactables currentInteractable = null;

            for(int i = 0; i < currentBlockLine.length(); i++){
                if (currentBlockLine.charAt(i) == 'g'){
                    currentBlock = new Ground(i * 48, currentLineIndex * 48, this.roomID);
                } else if (currentBlockLine.charAt(i) == 'c') {
                    currentBlock = new Concrete(i * 48, currentLineIndex * 48, this.roomID);
                } else if (currentBlockLine.charAt(i) == 'b') {
                    currentBlock = new Brick(i * 48, currentLineIndex * 48, this.roomID);
                } else if (currentBlockLine.charAt(i) == '*') {
                    currentBlock = new InvisibleConcrete(i * 48, currentLineIndex * 48, this.roomID);
                } else if (currentBlockLine.charAt(i) == 'm' || currentBlockLine.charAt(i) == 'x' || currentBlockLine.charAt(i) == 'i') {
                    if (currentInteractableLine.charAt(i) == 'c') {
                        currentInteractable = new MysteryBlockCoin(i * 48, currentLineIndex * 48, this.roomID);
                    } else if (currentInteractableLine.charAt(i) == 'u') {
                        if(player.getMarioForm() == 0){
                            currentInteractable = new SuperMushroom(i * 48, currentLineIndex * 48, this.roomID);
                        } else if (player.getMarioForm() > 0){
                            currentInteractable = new FireFlower(i * 48, currentLineIndex * 48, this.roomID);
                        }
                    } else if (currentInteractableLine.charAt(i) == '1') {
                        currentInteractable = new OneUP(i * 48, currentLineIndex * 48, this.roomID);
                    } else if (currentInteractableLine.charAt(i) == 's') {
                        currentInteractable = new StarPower(i * 48, currentLineIndex * 48, this.roomID);
                    }
                    if (currentBlockLine.charAt(i) == 'm') {
                        currentBlock = new MysteryBox(i * 48, currentLineIndex * 48, this.roomID, currentInteractable);
                    } else if (currentBlockLine.charAt(i) == 'x') {
                        currentBlock = new MysteryBrick(i * 48, currentLineIndex * 48, this.roomID, currentInteractable);
                    } else if (currentBlockLine.charAt(i) == 'i') {
                        currentBlock = new InvisibleBox(i * 48, currentLineIndex * 48, this.roomID, currentInteractable);
                    }
                } else if (currentBlockLine.charAt(i) == 'p') {
                    currentBlock = new EmptyPipe(i * 48, currentLineIndex * 48, this.roomID, 13 - currentLineIndex);
                } else if (currentBlockLine.charAt(i) == '1') {
                    currentBlock = new EntrancePipe(i * 48, currentLineIndex * 48, this.roomID, 13 - currentLineIndex);
                } else if (currentBlockLine.charAt(i) == '2') {
                    currentBlock = new ExitPipe(i * 48, currentLineIndex * 48, this.roomID, 13 - currentLineIndex);
                } else if (currentBlockLine.charAt(i) == 's') {
                    currentBlock = new SideEntrancePipe(i * 48, currentLineIndex * 48, this.roomID);
                } else if (currentBlockLine.charAt(i) == 'd'){
                    currentBlock = new Platform(i * 48, currentLineIndex * 48, false, roomID);
                } else if (currentBlockLine.charAt(i) == 'u'){
                    currentBlock = new Platform(i * 48, currentLineIndex * 48, true, roomID);
                } else {
                    currentBlock = null;
                }
                if(currentInteractableLine.charAt(i) == '$'){
                    roomInteractablesList.add(new Coin(i * 48, currentLineIndex * 48, this.roomID));
                } else if(currentInteractableLine.charAt(i) == 'x'){
                    currentInteractable = new SpawnPoint(i * 48, levelID, roomID);
                } else if(currentInteractableLine.charAt(i) == 'y'){
                    currentInteractable = new Goal(i * 48, roomID);
                } else {
                    currentInteractable = null;
                }
                if(currentBlock != null){
                    roomBlockList.add(currentBlock);
                }
                if(currentInteractable != null){
                    roomInteractablesList.add(currentInteractable);
                }
            }
            currentLineIndex++;
        }
        blockMapFileScanner.close();
        interactablesMapFileScanner.close();

        while(enemyListFileScanner.hasNextLine()){
            String[] currentEnemyLine = enemyListFileScanner.nextLine().split(" ");
            Enemy currentEnemy = null;
            if(currentEnemyLine[0].equals("g")){
                currentEnemy = new Goomba(Integer.parseInt(currentEnemyLine[1]), Integer.parseInt(currentEnemyLine[2]), false, roomID);
            } else if(currentEnemyLine[0].equals("gk")){
                currentEnemy = new GreenKoopa(Integer.parseInt(currentEnemyLine[1]), Integer.parseInt(currentEnemyLine[2]), false, roomID);
            } else if(currentEnemyLine[0].equals("rk")){
                currentEnemy = new RedKoopa(Integer.parseInt(currentEnemyLine[1]), Integer.parseInt(currentEnemyLine[2]), false, roomID);
            } else if(currentEnemyLine[0].equals("p")){
                currentEnemy = new PiranhaPlant(Integer.parseInt(currentEnemyLine[1]), Integer.parseInt(currentEnemyLine[2]), roomID);
            }
            roomEnemyList.add(currentEnemy);
        }
        enemyListFileScanner.close();

        player.objectPhysics.aquireRoomAllElements(player, roomBlockList, roomInteractablesList, roomEnemyList);

        for(int i = 0; i < roomBlockList.size(); i++){
            roomBlockList.get(i).aquireRoomElementArrayLists(this.player, (ArrayList<NonMarioRoomElements>)((ArrayList<?>)this.roomBlockList), this.roomNonInteractablesList);
            roomBlockList.get(i).getPhysics().aquireRoomAllElements(player, roomBlockList, roomInteractablesList, roomEnemyList);
        }

        for(int i = 0; i < roomInteractablesList.size(); i++){
            roomInteractablesList.get(i).aquireRoomElementArrayLists(this.player, (ArrayList<NonMarioRoomElements>)((ArrayList<?>)this.roomInteractablesList), this.roomNonInteractablesList);
            roomInteractablesList.get(i).getPhysics().aquireRoomAllElements(player, roomBlockList, roomInteractablesList, roomEnemyList);
        }

        for(int i = 0; i < roomNonInteractablesList.size(); i++){
            roomNonInteractablesList.get(i).aquireRoomElementArrayLists(this.player, (ArrayList<NonMarioRoomElements>)((ArrayList<?>)this.roomNonInteractablesList), this.roomNonInteractablesList);
            roomNonInteractablesList.get(i).getPhysics().aquireRoomAllElements(player, roomBlockList, roomInteractablesList, roomEnemyList);
        }

        for(int i = 0; i < roomEnemyList.size(); i++){
            roomEnemyList.get(i).aquireRoomElementArrayLists(this.player, (ArrayList<NonMarioRoomElements>)((ArrayList<?>)this.roomEnemyList), this.roomNonInteractablesList);
            roomEnemyList.get(i).getPhysics().aquireRoomAllElements(player, roomBlockList, roomInteractablesList, roomEnemyList);
        }
    }

    Mario getPlayer(){ //getters and setters
        return this.player;
    }

    Camera getCamera(){
        return this.camera;
    }

    void aquirePhysicsArrayLists(){ //initializes ArrayLists for each object that has a Physics object
        if(this.player.getPhysics().nullRoomElements()){
            this.player.getPhysics().aquireRoomAllElements(this.player, this.roomBlockList, this.roomInteractablesList, this.roomEnemyList);
        }

        for(int i = 0; i < this.roomBlockList.size(); i++){
            if(this.roomBlockList.get(i).getPhysics().nullRoomElements()){
                this.roomBlockList.get(i).getPhysics().aquireRoomAllElements(this.player, this.roomBlockList, this.roomInteractablesList, this.roomEnemyList);
            }
        }
        for(int i = 0; i < this.roomInteractablesList.size(); i++){
            if(this.roomInteractablesList.get(i).getPhysics().nullRoomElements()){
                this.roomInteractablesList.get(i).getPhysics().aquireRoomAllElements(this.player, this.roomBlockList, this.roomInteractablesList, this.roomEnemyList);
            }
        }
        for(int i = 0; i < this.roomNonInteractablesList.size(); i++){
            if(this.roomNonInteractablesList.get(i).getPhysics().nullRoomElements()){
                this.roomNonInteractablesList.get(i).getPhysics().aquireRoomAllElements(this.player, this.roomBlockList, this.roomInteractablesList, this.roomEnemyList);
            }
        }
        for(int i = 0; i < this.roomEnemyList.size(); i++){
            if(this.roomEnemyList.get(i).getPhysics().nullRoomElements()){
                this.roomEnemyList.get(i).getPhysics().aquireRoomAllElements(this.player, this.roomBlockList, this.roomInteractablesList, this.roomEnemyList);
            }
        }
    }

    void aquirePaintComponentParameters(Graphics g, Game.GamePanel gamePanel){ //aquires painting objects needed to paint onto JPanel
        this.gamePanel = gamePanel;
        this.g = g;
    }

    void paintAndAnimateAllRoomElements(){ //Paints and animates each roomElement
        this.player.paintElement(this.g, this.gamePanel, this.camera);
        this.player.animateMario();

        for(int i = 0; i < this.roomEnemyList.size(); i++){
            this.roomEnemyList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomEnemyList.get(i).animateObject();
        }

        for(int i = 0; i < this.roomInteractablesList.size(); i++){
            this.roomInteractablesList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomInteractablesList.get(i).animateObject();
        }

        for(int i = 0; i < this.roomBlockList.size(); i++){
            this.roomBlockList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomBlockList.get(i).animateObject();
        }

        for(int i = 0; i < this.roomNonInteractablesList.size(); i++){
            this.roomNonInteractablesList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomBlockList.get(i).animateObject();
        }
    }

    void applyPhysicsForAllRoomElements(){
        this.player.getPhysics().applyGravity();
        this.player.getPhysics().applyAcceleration();
        this.player.getPhysics().applyVelocity();
        this.player.activateEnemyAction();
        this.player.activateInteractables();
        this.player.activateMysteryBlock();
        this.player.checkIfDucked();
        this.player.checkIfJumped();
        this.player.decrimentCountdowns();

        for(int i = 0; i < this.roomEnemyList.size(); i++){
            this.roomEnemyList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomEnemyList.get(i).animateObject();
        }

        for(int i = 0; i < this.roomInteractablesList.size(); i++){
            this.roomInteractablesList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomInteractablesList.get(i).animateObject();
        }

        for(int i = 0; i < this.roomBlockList.size(); i++){
            this.roomBlockList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomBlockList.get(i).animateObject();
        }

        for(int i = 0; i < this.roomNonInteractablesList.size(); i++){
            this.roomNonInteractablesList.get(i).paintElement(this.g, this.gamePanel, this.camera);
            this.roomBlockList.get(i).animateObject();
        }
    }
    
    void paintBackground(){
        this.centeredRoomBackground = this.roomBackground.getSubimage(this.camera.getCurrentCameraPosition(), 0, 768, 720);
        g.drawImage(this.centeredRoomBackground, 0, 0, this.gamePanel);
    }
}