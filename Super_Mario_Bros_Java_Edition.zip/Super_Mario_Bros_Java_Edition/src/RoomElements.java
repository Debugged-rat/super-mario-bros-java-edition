import java.awt.*;
import java.util.ArrayList;
import java.awt.image.BufferedImage;

abstract class RoomElements { //abstract class that defines every element that is in a room (e.g. Mario, Blocks, Interactables, etc.)
    Physics objectPhysics;
    int roomID;
    BufferedImage objectMainImage;
    BufferedImage objectSubImage;

    Physics getPhysics(){
        return this.objectPhysics;
    }

    void paintElement(Graphics g, Game.GamePanel gamePanel, Camera camera){
        if(this.objectPhysics.getDirection()){
            g.drawImage(objectSubImage, this.objectPhysics.getPositionXY()[0] - camera.getCurrentCameraPosition(), this.objectPhysics.getPositionXY()[1], gamePanel);
        } else {
            g.drawImage(objectSubImage, this.objectPhysics.getPositionXY()[0] - camera.getCurrentCameraPosition() + this.objectPhysics.getHitBoxXY()[0], this.objectPhysics.getPositionXY()[1], -(this.objectPhysics.getHitBoxXY()[0]), this.objectPhysics.getHitBoxXY()[1], gamePanel);
        }
    }
}

abstract class NonMarioRoomElements extends RoomElements{ //Specific abstract class for roomElements that aren't Mario, as the Mario class is an extreme exception compared to other classes
    int[][] animatedObjectFrames;
    Countdown frameDelayCountdown;
    private int currentFrameIndex = 0;

    Mario roomPlayer;
    ArrayList<NonMarioRoomElements> roomElementArrayList;
    ArrayList<NonInteractables> roomNonInteractableArrayList;

    void animateObject(){ //swaps between animation frames of roomElement if their animatedObjectFrames is not nothing
        if(animatedObjectFrames != null){
            this.objectSubImage = this.objectMainImage.getSubimage(this.animatedObjectFrames[currentFrameIndex][0], this.animatedObjectFrames[currentFrameIndex][1], this.objectPhysics.getHitBoxXY()[0], this.objectPhysics.getHitBoxXY()[1]);
            if(this.frameDelayCountdown.getCurrentFrameDelayCount() == 0){
                this.currentFrameIndex++;
                if(this.currentFrameIndex == animatedObjectFrames.length){
                    this.currentFrameIndex = 0;
                }
            }
            this.frameDelayCountdown.decrimentCurrentDelay();
        }
    }

    void aquireRoomElementArrayLists(Mario roomPlayer, ArrayList<NonMarioRoomElements> roomElementArrayList, ArrayList<NonInteractables> roomNonInteractableArrayList){
        this.roomPlayer = roomPlayer;
        this.roomElementArrayList = roomElementArrayList;
        this.roomNonInteractableArrayList = roomNonInteractableArrayList;
    }
}